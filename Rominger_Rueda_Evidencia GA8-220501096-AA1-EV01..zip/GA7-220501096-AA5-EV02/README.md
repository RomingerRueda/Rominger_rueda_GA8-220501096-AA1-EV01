# ExchangeSoft — integración de módulos

Proyecto web de intercambio de objetos. El código se organiza en una interfaz web (`fronted/`) y una API REST (`backend/`).

## Tecnologías

- Node.js y Express 5 para la API.
- MySQL mediante `mysql2`.
- `bcryptjs` para el hash de contraseñas.
- `jsonwebtoken` para autenticación JWT.
- `dotenv` para configuración local.
- `node:test` para pruebas unitarias.

## Configuración local

1. Instalar Node.js LTS y MySQL.
2. Abrir una terminal en `backend/`.
3. Copiar `.env.example` a `.env` y configurar los valores de la base de datos y `JWT_SECRET`.
4. Instalar dependencias: `npm install`.
5. Verificar que la base de datos `exchangesoft_db` y sus tablas coincidan con las consultas del código. El ZIP original no incluye un script SQL de creación de tablas; no se debe asumir que la base está creada.
6. Iniciar el backend: `npm start`.
7. Abrir `fronted/index.html` mediante Live Server o un servidor estático local autorizado en `CORS_ORIGINS`.

La API se configura por defecto en `http://localhost:3000`. Si se cambia el puerto, actualizar también las URL de la API del frontend.

## Pruebas

Desde la carpeta `backend/` ejecutar:

```bash
npm test
```

Las pruebas actuales cubren validaciones puras de registro, objetos, identificadores y solicitudes de intercambio. No requieren conexión a MySQL. Las pruebas de integración de la API requieren un servidor y una base de datos de pruebas configurados.

## Endpoints principales

- `POST /api/usuarios/registro`
- `POST /api/usuarios/login`
- `GET /api/usuarios/perfil` (protegido)
- `GET /api/objetos`
- `GET /api/objetos/mis-objetos` (protegido)
- `POST /api/objetos` (protegido)
- `DELETE /api/objetos/:id` (protegido)
- `POST /api/intercambios` (protegido)
- `GET /api/intercambios/mis-intercambios` (protegido)
- `PUT /api/intercambios/:id/responder` (protegido)

Las rutas protegidas aceptan `Authorization: Bearer <token>` y, por compatibilidad con el frontend original, también el token sin prefijo.

## Seguridad

- `.env` está excluido de Git; no publicar credenciales.
- Configurar `JWT_SECRET` con un secreto aleatorio y privado.
- `CORS_ORIGINS` debe limitarse a los orígenes utilizados en el ambiente.
- Los errores enviados al navegador no exponen mensajes internos de MySQL.
- Las publicaciones e intercambios deben validarse siempre en el servidor.

## Estado de validación

Se ejecutaron satisfactoriamente las cinco pruebas unitarias incluidas (`node --test`) y la comprobación sintáctica de los archivos JavaScript del backend. La API completa no se marca como probada de extremo a extremo porque requiere configurar una base de datos MySQL real y comprobar el esquema local.
