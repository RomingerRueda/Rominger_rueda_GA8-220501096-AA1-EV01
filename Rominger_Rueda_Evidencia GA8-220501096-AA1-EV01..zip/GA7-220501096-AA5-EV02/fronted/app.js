// app.js - Utilidades globales de ExchangeSoft

// Verificar si el usuario está logueado
function estaLogueado() {
  return !!localStorage.getItem('token');
}

// Obtener el usuario actual
function getUsuario() {
  return JSON.parse(localStorage.getItem('usuario') || 'null');
}

// Obtener el token
function getToken() {
  return localStorage.getItem('token');
}

// Cerrar sesión
function cerrarSesion() {
  localStorage.removeItem('token');
  localStorage.removeItem('usuario');
  window.location.href = 'index.html';
}
// Escapa texto procedente de la API antes de insertarlo en plantillas HTML.
function escapeHTML(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, character => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[character]);
}
