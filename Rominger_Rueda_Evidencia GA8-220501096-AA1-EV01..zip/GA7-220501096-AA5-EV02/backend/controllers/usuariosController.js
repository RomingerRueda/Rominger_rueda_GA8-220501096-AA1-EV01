'use strict';

const db = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validarRegistro, textoNoVacio } = require('../utils/validators');

const registrar = (req, res) => {
  const { nombre, correo, contrasena, telefono = null, direccion = null } = req.body || {};
  const errorValidacion = validarRegistro({ nombre, correo, contrasena });
  if (errorValidacion) return res.status(400).json({ mensaje: errorValidacion });
  if (telefono != null && (typeof telefono !== 'string' || telefono.length > 30)) {
    return res.status(400).json({ mensaje: 'El teléfono no puede superar 30 caracteres.' });
  }
  if (direccion != null && (typeof direccion !== 'string' || direccion.length > 255)) {
    return res.status(400).json({ mensaje: 'La dirección no puede superar 255 caracteres.' });
  }
  if (!process.env.JWT_SECRET) {
    return res.status(500).json({ mensaje: 'El servidor no tiene configurada la autenticación.' });
  }

  const hashContrasena = bcrypt.hashSync(contrasena, 10);
  const sql = 'INSERT INTO Usuarios (nombre, correo, contrasena, telefono, direccion) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [nombre.trim(), correo.trim().toLowerCase(), hashContrasena, telefono, direccion], (err, result) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ mensaje: 'Ese correo ya está registrado.' });
      console.error('Error al registrar usuario:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible registrar el usuario.' });
    }
    return res.status(201).json({ mensaje: 'Usuario registrado correctamente.', id: result.insertId });
  });
};

const login = (req, res) => {
  const { correo, contrasena } = req.body || {};
  if (!textoNoVacio(correo, 254) || typeof contrasena !== 'string' || !contrasena) {
    return res.status(400).json({ mensaje: 'Correo y contraseña son obligatorios.' });
  }
  if (!process.env.JWT_SECRET) {
    return res.status(500).json({ mensaje: 'El servidor no tiene configurada la autenticación.' });
  }

  db.query('SELECT id_usuario, nombre, correo, contrasena FROM Usuarios WHERE correo = ?', [correo.trim().toLowerCase()], (err, results) => {
    if (err) {
      console.error('Error al consultar usuario para login:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'Ocurrió un error al iniciar sesión.' });
    }
    if (!results || results.length === 0) return res.status(401).json({ mensaje: 'Correo o contraseña incorrectos.' });

    const usuario = results[0];
    const contrasenaValida = bcrypt.compareSync(contrasena, usuario.contrasena);
    if (!contrasenaValida) return res.status(401).json({ mensaje: 'Correo o contraseña incorrectos.' });

    const token = jwt.sign({ id: usuario.id_usuario, nombre: usuario.nombre }, process.env.JWT_SECRET, { expiresIn: '24h' });
    return res.json({
      mensaje: 'Inicio de sesión exitoso.',
      token,
      usuario: { id: usuario.id_usuario, nombre: usuario.nombre, correo: usuario.correo }
    });
  });
};

const verPerfil = (req, res) => {
  const sql = 'SELECT id_usuario, nombre, correo, telefono, direccion, fecha_registro, estado FROM Usuarios WHERE id_usuario = ?';
  db.query(sql, [req.usuario.id], (err, results) => {
    if (err) {
      console.error('Error al consultar perfil:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible consultar el perfil.' });
    }
    if (!results || results.length === 0) return res.status(404).json({ mensaje: 'Usuario no encontrado.' });
    return res.json(results[0]);
  });
};

module.exports = { registrar, login, verPerfil };
