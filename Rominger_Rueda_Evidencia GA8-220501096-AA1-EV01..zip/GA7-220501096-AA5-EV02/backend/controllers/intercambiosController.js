'use strict';

const db = require('../config/db');
const { validarSolicitudIntercambio, idPositivo } = require('../utils/validators');

const solicitar = (req, res) => {
  const { id_articulo_ofrecido, id_articulo_solicitado } = req.body || {};
  const errorValidacion = validarSolicitudIntercambio({ id_articulo_ofrecido, id_articulo_solicitado });
  if (errorValidacion) return res.status(400).json({ mensaje: errorValidacion });

  // Ambos artículos se consultan en una sola operación. El ofrecido debe pertenecer
  // al solicitante; el solicitado determina quién recibirá la propuesta.
  const sqlObjetos = 'SELECT id_articulo, id_usuario FROM Objetos WHERE id_articulo IN (?, ?)';
  db.query(sqlObjetos, [Number(id_articulo_ofrecido), Number(id_articulo_solicitado)], (err, objetos) => {
    if (err) {
      console.error('Error al validar artículos del intercambio:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible validar los artículos.' });
    }
    if (!objetos || objetos.length !== 2) return res.status(404).json({ mensaje: 'Uno o ambos artículos no existen.' });

    const ofrecido = objetos.find(o => Number(o.id_articulo) === Number(id_articulo_ofrecido));
    const solicitado = objetos.find(o => Number(o.id_articulo) === Number(id_articulo_solicitado));
    if (!ofrecido || !solicitado) return res.status(404).json({ mensaje: 'Uno o ambos artículos no existen.' });
    if (Number(ofrecido.id_usuario) !== Number(req.usuario.id)) {
      return res.status(403).json({ mensaje: 'Solo puedes ofrecer artículos que te pertenecen.' });
    }
    if (Number(solicitado.id_usuario) === Number(req.usuario.id)) {
      return res.status(400).json({ mensaje: 'No puedes solicitar un intercambio con tus propios objetos.' });
    }

    const sql = `INSERT INTO Intercambios (id_usuario_solicita, id_usuario_recibe, id_articulo_ofrecido, id_articulo_solicitado) VALUES (?, ?, ?, ?)`;
    db.query(sql, [req.usuario.id, solicitado.id_usuario, Number(id_articulo_ofrecido), Number(id_articulo_solicitado)], (insertErr, result) => {
      if (insertErr) {
        console.error('Error al crear intercambio:', insertErr.code || 'error de base de datos');
        return res.status(500).json({ mensaje: 'No fue posible crear la solicitud de intercambio.' });
      }
      return res.status(201).json({ mensaje: 'Solicitud de intercambio enviada.', id: result.insertId });
    });
  });
};

const verMisIntercambios = (req, res) => {
  const id = req.usuario.id;
  const sql = `
    SELECT i.*, u1.nombre AS solicitante, u2.nombre AS receptor,
      o1.nombre_articulo AS articulo_ofrecido, o2.nombre_articulo AS articulo_solicitado
    FROM Intercambios i
    JOIN Usuarios u1 ON i.id_usuario_solicita = u1.id_usuario
    JOIN Usuarios u2 ON i.id_usuario_recibe = u2.id_usuario
    JOIN Objetos o1 ON i.id_articulo_ofrecido = o1.id_articulo
    JOIN Objetos o2 ON i.id_articulo_solicitado = o2.id_articulo
    WHERE i.id_usuario_solicita = ? OR i.id_usuario_recibe = ?
    ORDER BY i.fecha_solicitud DESC`;
  db.query(sql, [id, id], (err, results) => {
    if (err) {
      console.error('Error al consultar intercambios:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible consultar los intercambios.' });
    }
    return res.json(results || []);
  });
};

const responder = (req, res) => {
  const { id } = req.params;
  const { estado } = req.body || {};
  if (!idPositivo(id)) return res.status(400).json({ mensaje: 'El identificador del intercambio no es válido.' });
  if (!['aceptado', 'rechazado'].includes(estado)) {
    return res.status(400).json({ mensaje: 'Estado inválido. Usa aceptado o rechazado.' });
  }

  // Solo el receptor puede responder y únicamente mientras la solicitud esté pendiente.
  const sql = `UPDATE Intercambios SET estado_intercambio = ? WHERE id_intercambio = ? AND id_usuario_recibe = ? AND estado_intercambio = 'pendiente'`;
  db.query(sql, [estado, Number(id), req.usuario.id], (err, result) => {
    if (err) {
      console.error('Error al responder intercambio:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible responder el intercambio.' });
    }
    if (result.affectedRows === 0) return res.status(404).json({ mensaje: 'Intercambio pendiente no encontrado o no tienes permiso para responderlo.' });
    return res.json({ mensaje: `Intercambio ${estado} correctamente.` });
  });
};

module.exports = { solicitar, verMisIntercambios, responder };
