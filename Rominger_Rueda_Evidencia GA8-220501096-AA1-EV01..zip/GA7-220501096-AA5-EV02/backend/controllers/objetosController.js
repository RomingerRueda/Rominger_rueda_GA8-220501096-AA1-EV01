'use strict';

const db = require('../config/db');
const { validarObjeto, idPositivo } = require('../utils/validators');

const publicar = (req, res) => {
  const { nombre_articulo, descripcion = '', categoria = 'Otro', estado_objeto = 'usado' } = req.body || {};
  const errorValidacion = validarObjeto({ nombre_articulo, descripcion, categoria, estado_objeto });
  if (errorValidacion) return res.status(400).json({ mensaje: errorValidacion });

  const sql = 'INSERT INTO Objetos (nombre_articulo, descripcion, categoria, estado_objeto, id_usuario) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [nombre_articulo.trim(), descripcion.trim(), categoria.trim(), estado_objeto, req.usuario.id], (err, result) => {
    if (err) {
      console.error('Error al publicar objeto:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible publicar el objeto.' });
    }
    return res.status(201).json({ mensaje: 'Objeto publicado correctamente.', id: result.insertId });
  });
};

const verTodos = (_req, res) => {
  const sql = `SELECT o.*, u.nombre AS propietario FROM Objetos o JOIN Usuarios u ON o.id_usuario = u.id_usuario ORDER BY o.fecha_publicacion DESC`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al consultar objetos:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible consultar los objetos.' });
    }
    return res.json(results || []);
  });
};

const verMisObjetos = (req, res) => {
  db.query('SELECT * FROM Objetos WHERE id_usuario = ? ORDER BY fecha_publicacion DESC', [req.usuario.id], (err, results) => {
    if (err) {
      console.error('Error al consultar objetos del usuario:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible consultar tus objetos.' });
    }
    return res.json(results || []);
  });
};

const eliminar = (req, res) => {
  const { id } = req.params;
  if (!idPositivo(id)) return res.status(400).json({ mensaje: 'El identificador del objeto no es válido.' });
  const sql = 'DELETE FROM Objetos WHERE id_articulo = ? AND id_usuario = ?';
  db.query(sql, [Number(id), req.usuario.id], (err, result) => {
    if (err) {
      console.error('Error al eliminar objeto:', err.code || 'error de base de datos');
      return res.status(500).json({ mensaje: 'No fue posible eliminar el objeto.' });
    }
    if (result.affectedRows === 0) return res.status(404).json({ mensaje: 'Objeto no encontrado o no tienes permiso para eliminarlo.' });
    return res.json({ mensaje: 'Objeto eliminado correctamente.' });
  });
};

module.exports = { publicar, verTodos, verMisObjetos, eliminar };
