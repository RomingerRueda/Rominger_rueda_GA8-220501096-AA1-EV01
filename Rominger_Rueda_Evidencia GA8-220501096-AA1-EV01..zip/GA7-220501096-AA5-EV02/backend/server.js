'use strict';

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();

const origins = (process.env.CORS_ORIGINS || 'http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:3000,http://localhost:3000,file://')
  .split(',').map(origin => origin.trim()).filter(Boolean);

app.disable('x-powered-by');
app.use(cors({
  origin(origin, callback) {
    // Las solicitudes sin Origin (p. ej., Postman o llamadas servidor-servidor) se permiten.
    if (!origin || origins.includes('*') || origins.includes(origin)) return callback(null, true);
    return callback(new Error('Origen no autorizado por la política CORS.'));
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '100kb' }));

// Carga la conexión MySQL y registra los módulos de la API.
require('./config/db');
app.use('/api/usuarios', require('./routes/usuarios'));
app.use('/api/objetos', require('./routes/objetos'));
app.use('/api/intercambios', require('./routes/intercambios'));

app.get('/', (_req, res) => {
  res.json({ mensaje: 'ExchangeSoft API funcionando correctamente' });
});

app.use((req, res) => {
  res.status(404).json({ mensaje: 'Ruta no encontrada.' });
});

app.use((err, _req, res, _next) => {
  if (err && err.message === 'Origen no autorizado por la política CORS.') {
    return res.status(403).json({ mensaje: 'Origen no autorizado.' });
  }
  if (err instanceof SyntaxError && 'body' in err) {
    return res.status(400).json({ mensaje: 'El cuerpo JSON de la solicitud no es válido.' });
  }
  console.error('Error no controlado en la solicitud:', err && err.message ? err.message : 'Error desconocido');
  return res.status(500).json({ mensaje: 'Ocurrió un error interno del servidor.' });
});

if (require.main === module) {
  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, () => console.log(`ExchangeSoft API escuchando en http://localhost:${PORT}`));
}

module.exports = app;
