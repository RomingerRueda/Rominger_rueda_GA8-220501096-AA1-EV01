'use strict';

const mysql = require('mysql2');

const required = ['DB_HOST', 'DB_USER', 'DB_NAME'];
const missing = required.filter(key => !process.env[key]);
if (missing.length) {
  console.error(`Configuración de base de datos incompleta. Faltan: ${missing.join(', ')}`);
}

const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME,
  port: Number(process.env.DB_PORT) || 3306,
  charset: 'utf8mb4'
});

connection.connect(err => {
  if (err) {
    console.error('No fue posible conectar con MySQL. Verifica el servicio y las variables de entorno.');
    console.error(`Código de error: ${err.code || 'desconocido'}`);
    return;
  }
  console.log('Conexión con MySQL establecida.');
});

module.exports = connection;
