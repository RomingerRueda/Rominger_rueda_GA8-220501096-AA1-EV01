'use strict';

const jwt = require('jsonwebtoken');

const verificarToken = (req, res, next) => {
  const header = req.headers.authorization;
  if (!header) {
    return res.status(401).json({ mensaje: 'Acceso denegado: se requiere autenticación.' });
  }

  // Acepta el formato recomendado "Bearer <token>" y conserva compatibilidad
  // con el formato anterior de ExchangeSoft, que enviaba solo el token.
  const token = /^Bearer\s+/i.test(header) ? header.replace(/^Bearer\s+/i, '').trim() : header.trim();
  if (!token || !process.env.JWT_SECRET) {
    return res.status(401).json({ mensaje: 'No fue posible validar la autenticación.' });
  }

  try {
    req.usuario = jwt.verify(token, process.env.JWT_SECRET);
    if (!req.usuario || !Number.isSafeInteger(Number(req.usuario.id))) {
      return res.status(401).json({ mensaje: 'Token inválido o expirado.' });
    }
    next();
  } catch (_error) {
    return res.status(401).json({ mensaje: 'Token inválido o expirado.' });
  }
};

module.exports = { verificarToken };
