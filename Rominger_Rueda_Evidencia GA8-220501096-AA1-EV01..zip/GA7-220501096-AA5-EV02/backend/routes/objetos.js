const express = require('express');
const router = express.Router();
const { publicar, verTodos, verMisObjetos, eliminar } = require('../controllers/objetosController');
const { verificarToken } = require('../middlewares/auth');

router.get('/', verTodos);
router.get('/mis-objetos', verificarToken, verMisObjetos);
router.post('/', verificarToken, publicar);
router.delete('/:id', verificarToken, eliminar);

module.exports = router;