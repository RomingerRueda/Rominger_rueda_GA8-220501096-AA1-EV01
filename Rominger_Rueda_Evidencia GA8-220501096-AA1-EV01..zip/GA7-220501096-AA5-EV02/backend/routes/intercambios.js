const express = require('express');
const router = express.Router();
const { solicitar, verMisIntercambios, responder } = require('../controllers/intercambiosController');
const { verificarToken } = require('../middlewares/auth');

router.post('/', verificarToken, solicitar);
router.get('/mis-intercambios', verificarToken, verMisIntercambios);
router.put('/:id/responder', verificarToken, responder);

module.exports = router;