const express = require('express');
const router = express.Router();
const { registrar, login, verPerfil } = require('../controllers/usuariosController');
const { verificarToken } = require('../middlewares/auth');

router.post('/registro', registrar);
router.post('/login', login);
router.get('/perfil', verificarToken, verPerfil);

module.exports = router;