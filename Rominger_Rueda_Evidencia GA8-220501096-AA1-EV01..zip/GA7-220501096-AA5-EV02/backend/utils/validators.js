'use strict';

const ESTADOS_OBJETO = new Set(['nuevo', 'usado', 'buen estado']);
const ESTADOS_INTERCAMBIO = new Set(['pendiente', 'aceptado', 'rechazado']);

function textoNoVacio(value, maxLength = 255) {
  return typeof value === 'string' && value.trim().length > 0 && value.trim().length <= maxLength;
}

function validarRegistro({ nombre, correo, contrasena }) {
  if (!textoNoVacio(nombre, 100)) return 'El nombre es obligatorio y debe tener máximo 100 caracteres.';
  if (!textoNoVacio(correo, 254) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo.trim())) {
    return 'Debes ingresar un correo electrónico válido.';
  }
  if (typeof contrasena !== 'string' || contrasena.length < 8 || contrasena.length > 72) {
    return 'La contraseña debe tener entre 8 y 72 caracteres.';
  }
  return null;
}

function validarObjeto({ nombre_articulo, descripcion, categoria, estado_objeto }) {
  if (!textoNoVacio(nombre_articulo, 120)) return 'El nombre del artículo es obligatorio y debe tener máximo 120 caracteres.';
  if (descripcion != null && (typeof descripcion !== 'string' || descripcion.length > 2000)) {
    return 'La descripción debe ser texto y no superar 2000 caracteres.';
  }
  if (categoria != null && (typeof categoria !== 'string' || categoria.length > 80)) {
    return 'La categoría no es válida.';
  }
  if (estado_objeto != null && !ESTADOS_OBJETO.has(estado_objeto)) {
    return 'El estado del objeto debe ser nuevo, usado o buen estado.';
  }
  return null;
}

function idPositivo(value) {
  const n = Number(value);
  return Number.isSafeInteger(n) && n > 0;
}

function validarSolicitudIntercambio({ id_articulo_ofrecido, id_articulo_solicitado }) {
  if (!idPositivo(id_articulo_ofrecido) || !idPositivo(id_articulo_solicitado)) {
    return 'Debes indicar identificadores válidos para ambos artículos.';
  }
  if (Number(id_articulo_ofrecido) === Number(id_articulo_solicitado)) {
    return 'No puedes ofrecer y solicitar el mismo artículo.';
  }
  return null;
}

module.exports = {
  ESTADOS_OBJETO,
  ESTADOS_INTERCAMBIO,
  validarRegistro,
  validarObjeto,
  validarSolicitudIntercambio,
  idPositivo,
  textoNoVacio
};
