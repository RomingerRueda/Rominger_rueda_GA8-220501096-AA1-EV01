'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  validarRegistro,
  validarObjeto,
  validarSolicitudIntercambio,
  idPositivo
} = require('../utils/validators');

test('registro acepta datos básicos válidos', () => {
  assert.equal(validarRegistro({ nombre: 'Ana Pérez', correo: 'ana@example.com', contrasena: 'claveSegura123' }), null);
});

test('registro rechaza correo inválido y contraseña corta', () => {
  assert.match(validarRegistro({ nombre: 'Ana', correo: 'correo-invalido', contrasena: '12345678' }), /correo/i);
  assert.match(validarRegistro({ nombre: 'Ana', correo: 'ana@example.com', contrasena: '123' }), /contraseña/i);
});

test('objeto requiere nombre y estado permitido', () => {
  assert.match(validarObjeto({ nombre_articulo: ' ', estado_objeto: 'nuevo' }), /nombre/i);
  assert.match(validarObjeto({ nombre_articulo: 'Libro', estado_objeto: 'desconocido' }), /estado/i);
  assert.equal(validarObjeto({ nombre_articulo: 'Libro', descripcion: 'En buen estado', categoria: 'Libros', estado_objeto: 'usado' }), null);
});

test('solicitud de intercambio requiere dos identificadores válidos y distintos', () => {
  assert.match(validarSolicitudIntercambio({ id_articulo_ofrecido: 1, id_articulo_solicitado: 1 }), /mismo artículo/i);
  assert.match(validarSolicitudIntercambio({ id_articulo_ofrecido: 'abc', id_articulo_solicitado: 2 }), /identificadores/i);
  assert.equal(validarSolicitudIntercambio({ id_articulo_ofrecido: 4, id_articulo_solicitado: 9 }), null);
});

test('idPositivo solo acepta enteros positivos seguros', () => {
  assert.equal(idPositivo('15'), true);
  assert.equal(idPositivo('0'), false);
  assert.equal(idPositivo('-3'), false);
  assert.equal(idPositivo('1.5'), false);
});
